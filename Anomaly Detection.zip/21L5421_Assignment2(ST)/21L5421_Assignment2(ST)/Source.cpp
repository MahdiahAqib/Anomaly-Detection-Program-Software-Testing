#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <unordered_map>
#include <vector>
#include <algorithm> 

using namespace std;

// Type 1: Defined and Redefined
// Type 2: Defined but Unreferenced
// Type 3: Undefined but Referenced

// Function to trim leading and trailing whitespace
string trim(const string& str) {
    size_t first = str.find_first_not_of(' ');
    if (string::npos == first) {
        return str;
    }
    size_t last = str.find_last_not_of(' ');
    return str.substr(first, (last - first + 1));
}

bool isVariableDeclaration(const string& token) {
    // Check if the token contains a data type followed by a variable name
    // We assume that a valid variable declaration contains at least two words separated by whitespace
    size_t spacePos = token.find(' ');
    if (spacePos != string::npos) {
        string dataType = token.substr(0, spacePos);
        // Check if the data type is valid (e.g., "int", "float", "double", "char", etc.)
        // You may need to extend this check based on the data types allowed in your code
        if (dataType == "int" || dataType == "float" || dataType == "double" || dataType == "char") {
            return true;
        }
    }
    return false;
}

void detectAnomalies(stringstream& ss) {
    // Vector of pairs to store the parameters passed to the function
    vector<pair<string, bool>> parameters;

    // Read the first line of the code
    string firstLine;
    getline(ss, firstLine);

    // Initialize a stringstream to read the first line
    stringstream firstLineStream(firstLine);

    // Skip the return type (void)
    string returnType;
    firstLineStream >> returnType;

    // Read the function name
    string functionName;
    firstLineStream >> functionName;

    int check_first = 0;
    // Read the parameters
    string parameter;
    string line;
    while (firstLineStream >> parameter)
    {

        if (check_first % 2 == 0)
        {
            // Remove any commas or closing brackets at the end of the parameter
            while (!parameter.empty() && (parameter.back() == ',' || parameter.back() == ')' || parameter.back() == ']' || parameter.back() == '[')) {
                parameter.pop_back();
            }

            // Add the parameter to the vector with its reference attribute set to false
            parameters.push_back(make_pair(parameter, false));
        }

        check_first++;
    }

    //UPTO NOW WE HAVE READ THE FUNCTION PARAMETERS AND SAVED THEIR REFERENCED AS FALSE


    // Read the rest of the code line by line
    while (getline(ss, line))
    {
        stringstream lineStream(line);
        string token;

        if (lineStream.str().find('=') != string::npos &&
            (lineStream.str().find("int") != string::npos ||
                lineStream.str().find("float") != string::npos ||
                lineStream.str().find("double") != string::npos ||
                lineStream.str().find("char") != string::npos))
        {
            // Process variable declaration with initialization
            string lineContent = lineStream.str();
            size_t pos = lineContent.find('=');
            string variableNames = lineContent.substr(0, pos);

            // Remove data type keyword if it's at the beginning of the string followed by a space
            if (!variableNames.empty()) {
                if (variableNames.substr(0, 5) == "float ") {
                    variableNames.erase(0, 5);
                }
                else if (variableNames.substr(0, 4) == "int ") {
                    variableNames.erase(0, 4);
                }
                else if (variableNames.substr(0, 6) == "double ") {
                    variableNames.erase(0, 6);
                }
                else if (variableNames.substr(0, 5) == "char ") {
                    variableNames.erase(0, 5);
                }
                else if (variableNames.substr(0, 6) == "short ") {
                    variableNames.erase(0, 6);
                }
                else if (variableNames.substr(0, 7) == "long ") {
                    variableNames.erase(0, 7);
                }
            }

            stringstream varNamesStream(variableNames);
            string variableName;
            while (getline(varNamesStream, variableName, ',')) {
                trim(variableName);
                // Add variable to the parameters list if not already present
                bool found = false;
                for (auto& param : parameters) {
                    if (param.first == variableName) {
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    parameters.push_back({ variableName, false });
                }
            }
        }

        // Check for if-else statements
        else if (lineStream.str().find("if") != string::npos || lineStream.str().find("else") != string::npos)
        {
            // Extract the condition part within the parentheses
            size_t startPos = line.find('(');
            size_t endPos = line.find(')');
            if (startPos != string::npos && endPos != string::npos && endPos > startPos + 1)
            {
                string condition = line.substr(startPos + 1, endPos - startPos - 1);
                stringstream conditionStream(condition);
                string conditionToken;
                while (conditionStream >> conditionToken)
                {
                    // Check if the condition token is a variable
                    if (isalpha(conditionToken[0]))
                    {
                        bool found = false; // Flag to track if variable is found in parameter list

                        // Check if the token exists in the list of variables
                        for (auto& param : parameters)
                        {
                            if (trim(conditionToken) == trim(param.first))
                            {
                                found = true;
                                // If the variable is found, mark it as referenced
                                param.second = true;
                                break;
                            }
                        }

                        // If the variable is not found in the list of variables, it is undefined but referenced
                        if (!found)
                        {
                            cout << "Anomaly: Undefined but Referenced - Variable: " << conditionToken << endl;
                        }
                    }
                }

            }

        }

        // Check if lineStream contains '=', indicating an assignment
        else if (lineStream.str().find('=') != string::npos &&
            lineStream.str().find("int") == string::npos &&
            lineStream.str().find("float") == string::npos &&
            lineStream.str().find("double") == string::npos &&
            lineStream.str().find("char") == string::npos)
        {
            string lineContent = lineStream.str();

            // Extract the right -hand side of the assignment (the expression after '=')
            size_t pos = lineContent.find('=');
            string rhs = lineContent.substr(pos + 1);

            // Tokenize the right-hand side to check for references to variables
            stringstream rhsStream(rhs);
            string rhsToken;
            while (rhsStream >> rhsToken)
            {
                // Check if the token is a variable
                if (isalpha(rhsToken[0]))
                {
                    bool found = false; // Flag to track if variable is found in parameter list

                    // Check if the token exists in the list of variables
                    for (auto& param : parameters)
                    {
                        if (trim(rhsToken) == trim(param.first))
                        {
                            found = true;
                            // If the variable is found, mark it as referenced
                            param.second = true;
                            break;
                        }
                    }

                    // If the variable is not found in the list of variables, it is undefined but referenced
                    if (!found)
                    {
                        cout << "Anomaly: Undefined but Referenced - Variable: " << rhsToken << endl;
                    }
                }
            }

            // Extract the variable name from the left-hand side of the assignment (the expression before '=')
            string variableName = trim(lineContent.substr(0, pos));

            bool found = false; // Flag to track if variable is found in parameter list
            for (auto& param : parameters)
            {
                if (trim(variableName) == trim(param.first))
                {
                    found = true;
                    // If the variable is found and it was not referenced before, report it as "Defined and Redefined"
                    if (!param.second)
                    {
                        cout << "Anomaly: Defined and Redefined - Variable: " << variableName << endl;
                    }
                    break;
                }
            }

            // If the variable is not found in the list of variables, add it because it is being defined
            if (!found)
            {
                parameters.push_back({ variableName, false });
            }
             }
    


        

             // Check for return statements
        else if (lineStream.str().find("return") != string::npos)
        {
            size_t startPos = line.find("return") + 6;
            size_t endPos = line.find(';');
            if (startPos != string::npos && endPos != string::npos && endPos > startPos)
            {
                string variableName = line.substr(startPos, endPos - startPos);

                // Remove leading whitespace characters
                size_t firstCharIndex = variableName.find_first_not_of(" \t");
                if (firstCharIndex != string::npos)
                {
                    variableName = variableName.substr(firstCharIndex);
                }

                trim(variableName);

                if (!variableName.empty() && isalpha(variableName[0]))
                {
                    bool found = false;
                    for (auto& param : parameters)
                    {
                        if (trim(variableName) == trim(param.first))
                        {
                            found = true;
                            param.second = true; // Mark as referenced
                            break;
                        }
                    }

                    if (!found)
                    {
                        cout << "Anomaly: Undefined but Referenced - Variable:" << variableName << endl;
                    }
                }
            }
            }


    }

    // Print the parameters with their reference attribute
    for (const auto& param : parameters)
    {
        if (!param.second) {
            cout << "Anomaly: Defined but Unreferenced - Variable: " << param.first << endl;
        }
    }
}


int main()
{
    ifstream inputFile("input.txt");
    if (!inputFile)
    {
        cerr << "Error: Unable to open input file." << endl;
        return 1;
    }

    stringstream buffer;
    buffer << inputFile.rdbuf();

    detectAnomalies(buffer);

    return 0;
}
